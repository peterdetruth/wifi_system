<?php

namespace App\Services;

use App\Models\MpesaTransactionModel;
use App\Models\PaymentsModel;
use App\Models\ClientModel;
use App\Models\PackageModel;
use CodeIgniter\Database\ConnectionInterface;

class MpesaService
{
    protected MpesaTransactionModel $transactionModel;
    protected PaymentsModel $paymentsModel;
    protected ClientModel $clientModel;
    protected PackageModel $packageModel;
    protected MpesaLogger $logger;
    protected ConnectionInterface $db;

    public function __construct(MpesaLogger $logger)
    {
        $this->logger = $logger;
        $this->transactionModel = new MpesaTransactionModel();
        $this->paymentsModel = new PaymentsModel();
        $this->clientModel = new ClientModel();
        $this->packageModel = new PackageModel();
        $this->db = \Config\Database::connect();
    }

    /**
     * Initiates an M-PESA transaction (STK Push)
     * Returns checkoutRequestID on success, false on failure
     */
    public function initiateTransaction(
        int $clientId,
        int $packageId,
        float $amount,
        string $phone,
        ?string $merchantRequestId = null,
        ?string $checkoutRequestId = null
    ): string|false {
        try {
            // Generate checkoutRequestID if not provided
            $checkoutRequestId = $checkoutRequestId ?? 'CHK_' . substr(md5(uniqid((string)microtime(), true)), 0, 12);

            // Insert transaction record
            $data = [
                'client_id' => $clientId,
                'package_id' => $packageId,
                'amount' => $amount,
                'phone_number' => $phone,
                'merchant_request_id' => $merchantRequestId ?? 'N/A',
                'checkout_request_id' => $checkoutRequestId,
                'status' => 'Pending',
                'created_at' => date('Y-m-d H:i:s'),
            ];

            $this->transactionModel->insert($data);
            $dbErr = $this->db->error();
            if ($dbErr['code'] !== 0) {
                $this->logger->error("DB insert error in initiateTransaction", $dbErr);
                return false;
            }

            $this->logger->info("Transaction initiated", $data);

            return $checkoutRequestId;
        } catch (\Throwable $e) {
            $this->logger->error("Exception in initiateTransaction", [
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);
            return false;
        }
    }

    /**
     * Handles M-PESA callback
     */
    public function handleCallback(array $callbackData): array
    {
        try {
            if (empty($callbackData['Body']['stkCallback'])) {
                $this->logger->error("Invalid callback payload", $callbackData);
                return ['ResultCode' => 1, 'ResultDesc' => 'Invalid payload'];
            }

            $callback = $callbackData['Body']['stkCallback'];
            $merchantRequestId = $callback['MerchantRequestID'] ?? null;
            $checkoutRequestId = $callback['CheckoutRequestID'] ?? null;
            $resultCode = (int)($callback['ResultCode'] ?? 0);
            $resultDesc = $callback['ResultDesc'] ?? '';

            $this->logger->info("Received callback", [
                'merchant_request_id' => $merchantRequestId,
                'checkout_request_id' => $checkoutRequestId,
                'result_code' => $resultCode,
                'result_desc' => $resultDesc
            ]);

            $transaction = $this->transactionModel->where('checkout_request_id', $checkoutRequestId)->first();

            if (!$transaction) {
                $this->logger->error("Transaction not found for callback", ['checkout_request_id' => $checkoutRequestId]);
                return ['ResultCode' => 1, 'ResultDesc' => 'Transaction not found'];
            }

            return $resultCode === 0
                ? $this->markTransactionSuccess($transaction, $callback['CallbackMetadata']['Item'] ?? [], $resultDesc)
                : $this->markTransactionFailed($transaction, $resultCode, $resultDesc);
        } catch (\Throwable $e) {
            $this->logger->error("Exception in handleCallback", [
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);
            return ['ResultCode' => 1, 'ResultDesc' => 'Internal error'];
        }
    }

    /**
     * Mark transaction failed
     */
    private function markTransactionFailed(array $transaction, int $resultCode, string $resultDesc): array
    {
        $updateData = [
            'status' => 'Failed',
            'result_code' => $resultCode,
            'result_desc' => $resultDesc,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->transactionModel->update($transaction['id'], $updateData);
        $this->logger->info("Transaction marked failed", ['transaction_id' => $transaction['id'], 'update' => $updateData]);

        return ['ResultCode' => 0, 'ResultDesc' => 'Acknowledged failure'];
    }

    /**
     * Mark transaction successful
     */
    private function markTransactionSuccess(array $transaction, array $metadata, string $resultDesc): array
    {
        $amount = null;
        $mpesaReceipt = null;
        $phone = null;
        $transactionDate = null;

        foreach ($metadata as $item) {
            $name = $item['Name'] ?? '';
            $value = $item['Value'] ?? null;

            switch ($name) {
                case 'Amount':
                    $amount = $value;
                    break;
                case 'MpesaReceiptNumber':
                    $mpesaReceipt = $value;
                    break;
                case 'PhoneNumber':
                    $phone = $value;
                    break;
                case 'TransactionDate':
                    $transactionDate = $value ? date('Y-m-d H:i:s', strtotime($value)) : null;
                    break;
            }
        }

        if (!$mpesaReceipt) {
            $this->logger->error("Missing MpesaReceiptNumber", ['transaction' => $transaction]);
            return ['ResultCode' => 1, 'ResultDesc' => 'Missing receipt'];
        }

        // Prevent duplicate payment
        $existingPayment = $this->paymentsModel->where('mpesa_receipt_number', $mpesaReceipt)->first();
        if ($existingPayment) {
            $this->logger->info("Duplicate payment detected", ['mpesa_receipt' => $mpesaReceipt]);
            return ['ResultCode' => 0, 'ResultDesc' => 'Duplicate ignored'];
        }

        // Update transaction
        $updateTx = [
            'amount' => $amount ?? $transaction['amount'],
            'phone_number' => $phone ?? $transaction['phone_number'],
            'mpesa_receipt_number' => $mpesaReceipt,
            'transaction_date' => $transactionDate ?? $transaction['transaction_date'],
            'status' => 'Success',
            'result_code' => 0,
            'result_desc' => $resultDesc,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $this->transactionModel->update($transaction['id'], $updateTx);
        $this->logger->info("Transaction marked successful", ['transaction_id' => $transaction['id'], 'update' => $updateTx]);

        return ['ResultCode' => 0, 'ResultDesc' => 'Callback processed successfully'];
    }
}
